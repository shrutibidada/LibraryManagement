	<ul>
	  <li><a href="/libraryManagement.php">Home</a></li>
	  <li><a href="/checkIn.php">Check In Book</a></li>
	  <li><a href="/newUser.php">Create New User</a></li>
	  <li><a href="/checkout.php">Check Out Book</a></li>
	  <li><a href="/payment.php">Payment</a></li>
	  <li><a href="/history.php">History</a></li>
	</ul>