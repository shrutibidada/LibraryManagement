<?php
echo date('Y-m-d h:i:s');
$d=strtotime("+14 days");
echo date("Y-m-d h:i:s", $d)
?>